# coding=utf-8
from JPGValidator import JPGValidator
from MSOLEValidator import MSOLEValidator
from PNGValidator import PNGValidator
from SQLiteValidator import SQLiteValidator
from ZIPValidator import ZIPValidator

__VER__ = "0.5.3"